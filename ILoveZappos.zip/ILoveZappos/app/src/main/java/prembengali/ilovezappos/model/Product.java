package prembengali.ilovezappos.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Prem on 2/6/2017.
 *
 * This class helps to retrieve all the results of the query search
 * Retrieves the data from the server and converts it and stores it in the
 * fields.
 * This class helps to display the details of the product, including price,
 * product picture.
 */
public class Product {

    @SerializedName("brandName")
    private String brandName;
    @SerializedName("colorId")
    private Integer colorId;
    @SerializedName("originalPrice")
    private String originalPrice;
    @SerializedName("percentOff")
    private String percentOff;
    @SerializedName("price")
    private String price;
    @SerializedName("productId")
    private Integer productId;
    @SerializedName("productName")
    private String productName;
    @SerializedName("productUrl")
    private String productUrl;
    @SerializedName("styleId")
    private Integer styleId;
    @SerializedName("thumbnailImageUrl")
    private String thumbnailImageUrl;

    /**
     * Constructor which initializes the fields
     * @param brandName brand name of the product
     * @param colorId is color id of the product
     * @param originalPrice is the original price of the product
     * @param percentOff is the percent off on products
     * @param price is the discounted price of the product
     * @param productId is the id of the product
     * @param productName is the name of the product
     * @param productUrl is the url of the product
     * @param styleId is the style id of the product
     * @param thumbnailImageUrl is the image url of the product
     */
    public Product(String brandName, Integer colorId, String originalPrice, String percentOff,
                   String price, Integer productId, String productName, String productUrl,
                   Integer styleId, String thumbnailImageUrl) {

        this.brandName = brandName;
        this.colorId = colorId;
        this.originalPrice = originalPrice;
        this.percentOff = percentOff;
        this.price = price;
        this.productId = productId;
        this.productName = productName;
        this.productUrl = productUrl;
        this.styleId = styleId;
        this.thumbnailImageUrl = thumbnailImageUrl;
    }

    /**
     * Getter method
     * @return gets the name of the brand
     */
    public String getBrandName() {
        return brandName;
    }

    /**
     * Setter method
     * @param brandName sets the name of the brand
     */
    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    /**
     * Getter method
     * @return gets the color id of the product
     */
    public Integer getColorId() {
        return colorId;
    }

    /**
     * Setter method
     * @param colorId sets the color id of the product
     */
    public void setColorId(Integer colorId) {
        this.colorId = colorId;
    }

    /**
     * Getter method
     * @return gets the original price of the product
     */
    public String getOriginalPrice() {
        return originalPrice;
    }

    /**
     * Setter method
     * @param originalPrice sets the original price of the product
     */
    public void setOriginalPrice(String originalPrice) {
        this.originalPrice = originalPrice;
    }

    /**
     * Getter method
     * @return gets the percent of discount
     */
    public String getPercentOff() {
        return percentOff;
    }

    /**
     * Setter method
     * @param percentOff sets the discount on the product
     */
    public void setPercentOff(String percentOff) {
        this.percentOff = percentOff;
    }

    /**
     * Getter method
     * @return gets the price of the product
     */
    public String getPrice() {
        return price;
    }

    /**
     * Setter method
     * @param price sets the price of the product
     */
    public void setPrice(String price) {
        this.price = price;
    }

    /**
     * Getter method
     * @return gets the id of the product
     */
    public Integer getProductId() {
        return productId;
    }

    /**
     * Setter method
     * @param productId sets the id of the product
     */
    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    /**
     * Getter method
     * @return gets the name of the product
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Setter method
     * @param productName sets the name of the product
     */
    public void setProductName(String productName) {
        this.productName = productName;
    }

    /**
     * Getter method
     * @return gets the url of the product
     */
    public String getProductUrl() {
        return productUrl;
    }

    /**
     * Setter method
     * @param productUrl sets the url of the product
     */
    public void setProductUrl(String productUrl) {
        this.productUrl = productUrl;
    }

    /**
     * Getter method
     * @return gets the id of style
     */
    public Integer getStyleId() {
        return styleId;
    }

    /**
     * Setter method
     * @param styleId sets the id of style
     */
    public void setStyleId(Integer styleId) {
        this.styleId = styleId;
    }

    /**
     * Getter method
     * @return url of the image
     */
    public String getThumbnailImageUrl() {
        return thumbnailImageUrl;
    }

    /**
     * Setter method
     * @param thumbnailImageUrl sets the image url
     */
    public void setThumbnailImageUrl(String thumbnailImageUrl) {
        this.thumbnailImageUrl = thumbnailImageUrl;
    }

}//end class Product
