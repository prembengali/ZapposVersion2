package prembengali.ilovezappos;


import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;


import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import prembengali.ilovezappos.model.Product;
import prembengali.ilovezappos.model.ProductResponse;
import prembengali.ilovezappos.adapter.ProductAdapter;
import prembengali.ilovezappos.rest.ApiClient;
import prembengali.ilovezappos.rest.ApiInterface;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();

    private final static String API_KEY = "b743e26728e16b81da139182bb2094357c31d331";

    static String query;

    SearchView searchView;

    public static FloatingActionButton fab;

    public static TextView itemCount;

    ImageButton addBtn;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.floating_button);

        if(API_KEY.isEmpty()) {

            Toast.makeText(getApplicationContext(), "Need API KEY", Toast.LENGTH_LONG);
            return;
        }


       fab = (FloatingActionButton) findViewById(R.id.fab);

        itemCount = (TextView) findViewById(R.id.item_count);
       /* fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(getApplicationContext(), "Need API KEY", Toast.LENGTH_LONG).show();
                System.out.println("HHHHHHHHHHHHHH");


            }
        });*/



        final RecyclerView recycleView = (RecyclerView) findViewById(R.id.product_recycler_view);
        LinearLayoutManager layoutManager=new LinearLayoutManager(this);
        recycleView.setLayoutManager(layoutManager);
        searchView = (SearchView) findViewById(R.id.search);

        ///////////////



        searchView.setIconifiedByDefault(false);


        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                query = newText;
                ApiInterface apiService =
                        ApiClient.getClient().create(ApiInterface.class);

                Call<ProductResponse> call = apiService.getProductDetails(query, API_KEY);
                call.enqueue(new Callback<ProductResponse>() {
                    @Override
                    public void onResponse
                            (Call <ProductResponse> call, Response<ProductResponse> response){

                        List<Product> movies = response.body().getResults();
                        recycleView.setAdapter(new ProductAdapter(movies,
                                R.layout.list_item_products, getApplicationContext()));
                    }

                    @Override
                    public void onFailure (Call <ProductResponse> call, Throwable t){
                        //Log error here since request failed
                        Log.e(TAG, toString());
                    }
                });
                Log.i("well", " this worked");
                return false;
            }
        });
    }
}

