package prembengali.ilovezappos.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by Prem on 2/6/2017.
 *
 * This class is used to get the response from the data
 * generated throught the url.
 * It classifies the JSON into the java objects
 */

public class ProductResponse {

    @SerializedName("currentResultCount")
    private int currentResultCount;
    @SerializedName("originalTerm")
    private String originalTerm;
    @SerializedName("results")
    private List<Product> results;
    @SerializedName("statusCode")
    private int statusCode;
    @SerializedName("term")
    String term;
    @SerializedName("totalResultCount")
    private int totalResultCount;


    /**
     * Getter method
     * @return key value pair for term
     */
    public String getTerm() {
        return term;
    }

    /**
     * Setter method
     * @param term set the key value pair for term
     */
    public void setTerm(String term) {
        this.term = term;
    }

    /**
     * Getter method
     * @return get key value pair of currentResultCount
     */
    public int getCurrentResultCount() {
        return currentResultCount;
    }

    /**
     * Setter method
     * @param currentResultCount set key value pair of currentResultCount
     */
    public void setCurrentResultCount(int currentResultCount) {
        this.currentResultCount = currentResultCount;
    }

    /**
     * Getter method
     * @return key value pair of originalTerm
     */
    public String getOriginalTerm() {
        return originalTerm;
    }

    /**
     * Setter method
     * @param originalTerm sets the key value pair of originalTerm
     */
    public void setOriginalTerm(String originalTerm) {
        this.originalTerm = originalTerm;
    }

    /**
     * Getter method
     * @return key value pair of results
     */
    public List<Product> getResults() {
        return results;
    }

    /**
     * Setter method
     * @param results to set the key value pairs of results
     */
    public void setResults(List<Product> results) {
        this.results = results;
    }

    /**
     * Getter method
     * @return key value pair for statusCode
     */
    public int getStatusCode() {
        return statusCode;
    }

    /**
     * Setter method
     * @param statusCode
     */
    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Getter method
     * @return key value pair of totalResultCount
     */
    public int getTotalResultCount() {
        return totalResultCount;
    }

    /**
     * Setter method
     * @param totalResultCount to set the key value pair of totalResultCount
     */
    public void setTotalResultCount(int totalResultCount) {
        this.totalResultCount = totalResultCount;
    }

}//end class ProductResponse

