package prembengali.ilovezappos.adapter;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.List;

import prembengali.ilovezappos.MainActivity;
import prembengali.ilovezappos.R;
import prembengali.ilovezappos.model.Product;

/**
 * Created by Prem on 2/6/2017.
 *
 * ProductAdapter class is used to fill data in the recyclerView
 *
 */
public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {

    /* List of products */
    private List<Product> product;
    /* Row layout of the product */
    private int rowLayout;
    /* Main context */
    private Context context;
    /* Item Counter */
    int counter;



    /**
     * ProductViewHolder class is used to hold the data in single recycler view
     */
    public static class ProductViewHolder extends  RecyclerView.ViewHolder {
        /* The layout of the product */
        LinearLayout productLayout;
        /* TextView to store the name of the product */
        TextView productName;
        /* TextView to store the brand of the product */
        TextView productBrand;
        /* TextView to store the price of the product */
        TextView productPrice;
        /* ImageView to store the photo of the product */
        ImageView productImage;
        /* Button to add product to cart */
        public ImageButton addBtn;




        /**
         * Constructor for the ProductViewHolder Class
         *
         * @param v is the view to hold
         */
        public ProductViewHolder(View v) {

            super(v);
            productLayout = (LinearLayout) v.findViewById(R.id.product_layout);
            productName = (TextView) v.findViewById(R.id.product_name);
            productBrand = (TextView) v.findViewById(R.id.product_brand);
            productPrice = (TextView) v.findViewById(R.id.price);
            productImage = (ImageView) v.findViewById(R.id.imageView);
            addBtn = (ImageButton) v.findViewById(R.id.addBtn);
            //fab = (FloatingActionButton) v.findViewById(R.id.fab);


        }

    }

    /**
     * Constructor for ProductAdapter class
     * @param product is the product
     * @param rowLayout the number of row layout
     * @param context the context
     */
    public ProductAdapter(List<Product> product, int rowLayout, Context context) {
        this.product = product;
        this.rowLayout = rowLayout;
        this.context = context;

    }

    /**
     * OnCreateViewHolder method is used to create a view
     * @param parent
     * @param viewType
     * @return the view
     */
    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(rowLayout, parent, false);
        return new ProductViewHolder(view);

    }

    /**
     * onBindViewHolder method is used to hold the data into the ui, imageView, TextView
     * @param holder is the holder for ProductViewHolder
     * @param position is the position of recyclerView
     */
    @Override
    public void onBindViewHolder(final ProductViewHolder holder, final int position) {
        holder.productName.setText(product.get(position).getProductName());
        holder.productBrand.setText(product.get(position).getBrandName());
        holder.productPrice.setText(product.get(position).getPrice());
        Picasso.with(context)
                .load(product.get(position)
                        .getThumbnailImageUrl()).into(holder.productImage );

        if (position + 1 == getItemCount()) {
            // set bottom margin to 72dp.
            setBottomMargin(holder.itemView, (int) (72 * Resources.getSystem().getDisplayMetrics().density));
        }
        else {
            setBottomMargin(holder.itemView, 0);
        }

            holder.addBtn.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {

                    counter++;

                    MainActivity.itemCount.setText("" + counter);

                    Animation animation = AnimationUtils.loadAnimation(context, R.anim.floating_button_animation);
                    MainActivity.fab.startAnimation(animation);


                }
            });

         }


    /**
     * This method is used to avoid floating button blocking the content of the screen
     * Takes care of the last thing in the app
     * @param view is the recyclerView
     * @param bottomMargin is to check the bottom Margin
     */
    public static void setBottomMargin(View view, int bottomMargin) {
        if (view.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
            params.setMargins(params.leftMargin, params.topMargin, params.rightMargin, bottomMargin);
            view.requestLayout();
        }
    }

    /**
     * Getter method
     * @return gets the size of the product
     */
    @Override
    public int getItemCount() {
        return product.size();
    }
}// end class ProductAdapter
